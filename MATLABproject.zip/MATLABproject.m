%% FREDRIC HOERR MATLAB ANAMORPHOSIS PROJECT PART 2
clear all
%read in the image
I = imread('art.png');
%convert image to grayscale
A = rgb2gray(I);
% open original image to compare
imshow(A)
%set y dimension 
M = 1;
%set x dimension
N = 4;
%get a zero matrix with the correct size
B = zeros([(size(A,1) / M) (size(A,2) / N)]);
%write every Mth row and Nth column to the zero matrix
B = A(1:M:end,1:N:end);
%show the matrix
figure,imshow(B)